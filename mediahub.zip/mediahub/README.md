# MediaHub — React Native (Expo) প্রোজেক্ট

স্ক্রিনশটে দেখানো ৮টা স্ক্রিন সহ একটা সম্পূর্ণ কোড স্ট্রাকচার। Expo + React Navigation দিয়ে বানানো, তাই একই কোড iOS আর Android দুটোতেই চলবে।

## চালানোর নিয়ম

```bash
cd mediahub
npm install
npx expo start
```

তারপর ফোনে **Expo Go** অ্যাপ দিয়ে QR কোড স্ক্যান করলেই অ্যাপ চলবে। অথবা `npm run android` / `npm run ios` দিয়ে এমুলেটরে চালানো যাবে।

## ফোল্ডার স্ট্রাকচার

```
mediahub/
├── App.js                          # এন্ট্রি পয়েন্ট
├── src/
│   ├── theme/colors.js             # সব রং, স্পেসিং, ফন্ট সাইজ — এক জায়গায়
│   ├── data/mockData.js            # ডামি ডেটা (পরে API দিয়ে রিপ্লেস করবেন)
│   ├── components/
│   │   ├── SectionHeader.js        # "Recently Played · See All" স্টাইলের হেডার
│   │   ├── MediaCard.js            # গান/ভিডিও/পডকাস্ট থাম্বনেইল কার্ড
│   │   └── MiniPlayer.js           # নিচের স্টিকি প্লেয়ার বার
│   ├── screens/
│   │   ├── HomeScreen.js           # ১. Home
│   │   ├── MusicLibraryScreen.js   # ২. Music Library
│   │   ├── VideoLibraryScreen.js   # ৩. Video Library
│   │   ├── PodcastsScreen.js       # ৪. Podcasts
│   │   ├── NowPlayingAudioScreen.js# ৫. Now Playing - Audio
│   │   ├── NowPlayingVideoScreen.js# ৬. Now Playing - Video
│   │   ├── PodcastEpisodeScreen.js # ৭. Podcast Episode
│   │   └── SearchScreen.js         # ৮. Search
│   └── navigation/RootNavigator.js # বটম ট্যাব + স্ট্যাক নেভিগেশন
└── package.json
```

## নেভিগেশন কীভাবে কাজ করে

- **Bottom Tabs** (`Home`, `Music`, `Video`, `Podcasts`, `Search`) — মূল ৫টা স্ক্রিন।
- **Modal Stack** — কোনো গান/ভিডিও/এপিসোডে ট্যাপ করলে `NowPlayingAudio`, `NowPlayingVideo`, বা `PodcastEpisode` মডাল হিসেবে উপরে ওঠে (নিচ থেকে সোয়াইপ করে বন্ধ করা যায়)।
- নিচের `MiniPlayer` যেকোনো ট্যাব স্ক্রিন থেকে ট্যাপ করলে Now Playing স্ক্রিনে নিয়ে যায়।

## পরের ধাপগুলো (বাস্তব অ্যাপের জন্য)

1. **আসল প্লেব্যাক**: `expo-av` বা `react-native-track-player` দিয়ে `mockData.js`-এর জায়গায় আসল অডিও/ভিডিও ইঞ্জিন বসাতে হবে।
2. **API/ব্যাকএন্ড**: `mockData.js`-এর ডামি অ্যারেগুলো fetch/axios কল দিয়ে রিপ্লেস করুন।
3. **স্টেট ম্যানেজমেন্ট**: প্লেব্যাক স্টেট (কী চলছে, পজিশন, কিউ) পুরো অ্যাপ জুড়ে দরকার হবে — Zustand বা Redux দিয়ে একটা গ্লোবাল প্লেয়ার কনটেক্সট বানানো ভালো, যাতে MiniPlayer সবসময় সঠিক ট্র্যাক দেখায়।
4. **ডাউনলোড/অফলাইন**: পডকাস্ট ডাউনলোড বাটনের জন্য `expo-file-system` লাগবে।
5. **অথেন্টিকেশন**: ইউজার লগইন/সাবস্ক্রিপশন থাকলে আলাদা `AuthNavigator` যোগ করুন।

## ডিজাইন সিস্টেম

সব রং `src/theme/colors.js`-এ। এক জায়গায় বদলালে পুরো অ্যাপে বদলে যাবে:
- **accent** (`#E63946`) — লাল, মূল ব্র্যান্ড রং, বাটন/অ্যাকটিভ স্টেট
- **music / video / podcast** — প্রতিটা মডিউলের নিজস্ব থিম রং (লাল/নীল/বেগুনি)
- **background/surface** — গাঢ় (dark) থিমের ৩ লেয়ার
