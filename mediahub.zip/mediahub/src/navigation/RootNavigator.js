import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

import HomeScreen from '../screens/HomeScreen';
import MusicLibraryScreen from '../screens/MusicLibraryScreen';
import VideoLibraryScreen from '../screens/VideoLibraryScreen';
import PodcastsScreen from '../screens/PodcastsScreen';
import SearchScreen from '../screens/SearchScreen';
import NowPlayingAudioScreen from '../screens/NowPlayingAudioScreen';
import NowPlayingVideoScreen from '../screens/NowPlayingVideoScreen';
import PodcastEpisodeScreen from '../screens/PodcastEpisodeScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TAB_ICONS = {
  Home: 'home',
  Music: 'musical-notes',
  Video: 'videocam',
  Podcasts: 'mic',
  Search: 'search',
};

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarStyle: {
          backgroundColor: colors.surfaceElevated,
          borderTopColor: colors.border,
          height: 60,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        tabBarIcon: ({ color, size }) => (
          <Ionicons name={TAB_ICONS[route.name]} size={size - 2} color={color} />
        ),
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Music" component={MusicLibraryScreen} />
      <Tab.Screen name="Video" component={VideoLibraryScreen} />
      <Tab.Screen name="Podcasts" component={PodcastsScreen} />
      <Tab.Screen name="Search" component={SearchScreen} />
    </Tab.Navigator>
  );
}

export default function RootNavigator() {
  return (
    <NavigationContainer
      theme={{
        dark: true,
        colors: {
          primary: colors.accent,
          background: colors.background,
          card: colors.surface,
          text: colors.textPrimary,
          border: colors.border,
          notification: colors.accent,
        },
      }}
    >
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Tabs" component={Tabs} />
        <Stack.Screen name="NowPlayingAudio" component={NowPlayingAudioScreen} options={{ presentation: 'modal' }} />
        <Stack.Screen name="NowPlayingVideo" component={NowPlayingVideoScreen} options={{ presentation: 'modal' }} />
        <Stack.Screen name="PodcastEpisode" component={PodcastEpisodeScreen} options={{ presentation: 'modal' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
