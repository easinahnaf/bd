import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '../theme/colors';

// size: 'sm' | 'md' | 'lg' controls thumbnail dimensions
// progress: 0-1 optional playback progress bar under the title
export default function MediaCard({ title, subtitle, image, size = 'md', progress, onPress, wide = false }) {
  const dim = size === 'lg' ? 140 : size === 'sm' ? 90 : 110;

  return (
    <TouchableOpacity style={[styles.card, { width: dim }]} onPress={onPress} activeOpacity={0.7}>
      <View style={[styles.imageWrap, { width: dim, height: wide ? dim * 0.65 : dim }]}>
        <Image source={{ uri: image }} style={styles.image} />
        <View style={styles.playBadge}>
          <Ionicons name="play" size={12} color="#fff" />
        </View>
      </View>
      <Text style={styles.title} numberOfLines={1}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle} numberOfLines={1}>{subtitle}</Text> : null}
      {typeof progress === 'number' && (
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { marginRight: spacing.md },
  imageWrap: { borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.surfaceElevated },
  image: { width: '100%', height: '100%' },
  playBadge: {
    position: 'absolute', bottom: 6, right: 6,
    width: 22, height: 22, borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center', justifyContent: 'center',
  },
  title: { ...typography.body, color: colors.textPrimary, marginTop: spacing.xs, fontWeight: '600' },
  subtitle: { ...typography.caption, color: colors.textSecondary },
  progressTrack: { height: 3, backgroundColor: colors.border, borderRadius: 2, marginTop: 4 },
  progressFill: { height: 3, backgroundColor: colors.accent, borderRadius: 2 },
});
