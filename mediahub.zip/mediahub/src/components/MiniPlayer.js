import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { colors, spacing, radius, typography } from '../theme/colors';

export default function MiniPlayer({ title, subtitle, image, isPlaying = true, target = 'NowPlayingAudio' }) {
  const navigation = useNavigation();

  return (
    <TouchableOpacity
      style={styles.wrap}
      activeOpacity={0.85}
      onPress={() => navigation.navigate(target)}
    >
      <View style={styles.progressTrack}>
        <View style={styles.progressFill} />
      </View>
      <View style={styles.row}>
        <Image source={{ uri: image }} style={styles.thumb} />
        <View style={{ flex: 1, marginLeft: spacing.sm }}>
          <Text style={styles.title} numberOfLines={1}>{title}</Text>
          <Text style={styles.subtitle} numberOfLines={1}>{subtitle}</Text>
        </View>
        <TouchableOpacity style={styles.playBtn} hitSlop={8}>
          <Ionicons name={isPlaying ? 'pause' : 'play'} size={18} color={colors.background} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    backgroundColor: colors.surfaceElevated,
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  progressTrack: { height: 2, backgroundColor: colors.border },
  progressFill: { height: 2, width: '35%', backgroundColor: colors.accent },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  thumb: { width: 40, height: 40, borderRadius: radius.sm },
  title: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  subtitle: { ...typography.caption, color: colors.textSecondary },
  playBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: colors.textPrimary,
    alignItems: 'center', justifyContent: 'center',
  },
});
