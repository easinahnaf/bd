import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';

const QUALITIES = ['1080p HD', '720p HD', '480p', '360p'];

export default function NowPlayingVideoScreen({ navigation }) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [showQuality, setShowQuality] = useState(false);
  const [quality, setQuality] = useState('1080p HD');

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.videoArea}>
        <Image source={{ uri: 'https://picsum.photos/seed/interstellarvid/800/450' }} style={styles.videoImage} />

        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.videoTitle}>Interstellar</Text>
          <View style={styles.topBarIcons}>
            <Ionicons name="tv-outline" size={20} color="#fff" />
            <Ionicons name="scan-outline" size={20} color="#fff" />
            <Ionicons name="ellipsis-vertical" size={20} color="#fff" />
          </View>
        </View>

        <View style={styles.centerControls}>
          <Ionicons name="play-back" size={30} color="#fff" />
          <TouchableOpacity onPress={() => setIsPlaying(!isPlaying)}>
            <Ionicons name={isPlaying ? 'pause' : 'play'} size={44} color="#fff" />
          </TouchableOpacity>
          <Ionicons name="play-forward" size={30} color="#fff" />
        </View>

        <View style={styles.bottomBar}>
          <Text style={styles.timeText}>1:15:32</Text>
          <View style={styles.seekTrack}>
            <View style={styles.seekFill} />
            <View style={styles.seekThumb} />
          </View>
          <Text style={styles.timeText}>2:49:04</Text>
        </View>
      </View>

      <View style={styles.controlsPanel}>
        <TouchableOpacity style={styles.panelItem} onPress={() => setShowQuality(!showQuality)}>
          <Ionicons name="lock-closed-outline" size={20} color={colors.textSecondary} />
          <Text style={styles.panelLabel}>Lock</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.panelItem} onPress={() => setShowQuality(!showQuality)}>
          <Text style={styles.speedText}>1.0x</Text>
          <Text style={styles.panelLabel}>Speed</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.panelItem}>
          <Ionicons name="headset-outline" size={20} color={colors.textSecondary} />
          <Text style={styles.panelLabel}>Audio</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.panelItem}>
          <Ionicons name="text-outline" size={20} color={colors.textSecondary} />
          <Text style={styles.panelLabel}>Subs</Text>
        </TouchableOpacity>
      </View>

      {showQuality && (
        <View style={styles.qualityMenu}>
          <Text style={styles.qualityMenuTitle}>Auto (1080p)</Text>
          {QUALITIES.map((q) => (
            <TouchableOpacity key={q} style={styles.qualityRow} onPress={() => { setQuality(q); setShowQuality(false); }}>
              <Text style={styles.qualityText}>{q}</Text>
              {quality === q && <Ionicons name="checkmark" size={16} color={colors.accent} />}
            </TouchableOpacity>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  videoArea: { width: '100%', aspectRatio: 16 / 10, backgroundColor: '#000' },
  videoImage: { ...StyleSheet.absoluteFillObject, width: '100%', height: '100%' },
  topBar: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingTop: spacing.sm,
  },
  videoTitle: { ...typography.body, color: '#fff', fontWeight: '600' },
  topBarIcons: { flexDirection: 'row', gap: spacing.md },
  centerControls: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xl,
  },
  bottomBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.md, paddingBottom: spacing.sm, gap: spacing.sm },
  timeText: { ...typography.caption, color: '#fff' },
  seekTrack: { flex: 1, height: 3, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 2 },
  seekFill: { position: 'absolute', left: 0, top: 0, width: '45%', height: 3, backgroundColor: colors.accent, borderRadius: 2 },
  seekThumb: { position: 'absolute', left: '45%', top: -4, width: 11, height: 11, borderRadius: 6, backgroundColor: colors.accent },
  controlsPanel: {
    flexDirection: 'row', justifyContent: 'space-around',
    paddingVertical: spacing.md, borderBottomWidth: 1, borderColor: colors.border,
  },
  panelItem: { alignItems: 'center', gap: 4 },
  speedText: { ...typography.body, color: colors.textPrimary, fontWeight: '700' },
  panelLabel: { ...typography.caption, color: colors.textSecondary },
  qualityMenu: {
    position: 'absolute', top: '38%', right: spacing.md,
    backgroundColor: colors.surfaceElevated, borderRadius: radius.md,
    padding: spacing.sm, width: 160, borderWidth: 1, borderColor: colors.border,
  },
  qualityMenuTitle: { ...typography.caption, color: colors.textSecondary, marginBottom: spacing.xs },
  qualityRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8 },
  qualityText: { ...typography.body, color: colors.textPrimary },
});
