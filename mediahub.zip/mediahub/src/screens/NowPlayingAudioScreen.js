import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';

export default function NowPlayingAudioScreen({ navigation }) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [position, setPosition] = useState(88); // seconds
  const duration = 225; // 3:45

  const format = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-down" size={26} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerLabel}>Now Playing</Text>
        <Ionicons name="ellipsis-horizontal" size={22} color={colors.textPrimary} />
      </View>

      <View style={styles.artworkWrap}>
        <Image source={{ uri: 'https://picsum.photos/seed/nowplaying/500/500' }} style={styles.artwork} />
      </View>

      <View style={styles.infoRow}>
        <View>
          <Text style={styles.title}>Midnight Drive</Text>
          <Text style={styles.subtitle}>The Night Owls · Neon Dreams</Text>
        </View>
        <Ionicons name="share-outline" size={20} color={colors.textSecondary} />
      </View>

      <Slider
        style={{ width: '100%', height: 30, marginTop: spacing.md }}
        minimumValue={0}
        maximumValue={duration}
        value={position}
        onValueChange={setPosition}
        minimumTrackTintColor={colors.accent}
        maximumTrackTintColor={colors.border}
        thumbTintColor={colors.accent}
      />
      <View style={styles.timeRow}>
        <Text style={styles.timeText}>{format(position)}</Text>
        <Text style={styles.timeText}>{format(duration)}</Text>
      </View>

      <View style={styles.controlsRow}>
        <Ionicons name="shuffle" size={20} color={colors.textSecondary} />
        <Ionicons name="play-skip-back" size={26} color={colors.textPrimary} />
        <TouchableOpacity style={styles.playBtn} onPress={() => setIsPlaying(!isPlaying)}>
          <Ionicons name={isPlaying ? 'pause' : 'play'} size={30} color={colors.background} />
        </TouchableOpacity>
        <Ionicons name="play-skip-forward" size={26} color={colors.textPrimary} />
        <Ionicons name="repeat" size={20} color={colors.textSecondary} />
      </View>

      <View style={styles.bottomRow}>
        <Ionicons name="volume-medium-outline" size={18} color={colors.textSecondary} />
        <View style={styles.volumeTrack}>
          <View style={styles.volumeFill} />
        </View>
        <Ionicons name="tv-outline" size={18} color={colors.textSecondary} />
        <Ionicons name="list-outline" size={18} color={colors.textSecondary} />
      </View>

      <View style={styles.upNext}>
        <View style={styles.upNextHeader}>
          <Text style={styles.upNextTitle}>Up Next</Text>
          <Text style={styles.seeAll}>Clear</Text>
        </View>
        {[
          { title: 'Neon Lights', subtitle: 'Luna Skies', time: '3:12' },
          { title: 'Afterglow', subtitle: 'Luna Skies', time: '4:05' },
          { title: 'Golden Hour', subtitle: 'Tom Misch', time: '3:50' },
        ].map((t) => (
          <View key={t.title} style={styles.upNextRow}>
            <View style={styles.upNextThumb} />
            <View style={{ flex: 1, marginLeft: spacing.sm }}>
              <Text style={styles.upNextItemTitle}>{t.title}</Text>
              <Text style={styles.upNextItemSubtitle}>{t.subtitle}</Text>
            </View>
            <Text style={styles.timeText}>{t.time}</Text>
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.md },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: spacing.sm },
  headerLabel: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
  artworkWrap: { alignItems: 'center', marginTop: spacing.lg },
  artwork: { width: '85%', aspectRatio: 1, borderRadius: radius.lg },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.lg },
  title: { ...typography.h1, color: colors.textPrimary },
  subtitle: { ...typography.body, color: colors.textSecondary, marginTop: 2 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between' },
  timeText: { ...typography.caption, color: colors.textSecondary },
  controlsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.lg, paddingHorizontal: spacing.sm },
  playBtn: { width: 64, height: 64, borderRadius: 32, backgroundColor: colors.textPrimary, alignItems: 'center', justifyContent: 'center' },
  bottomRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  volumeTrack: { flex: 1, height: 3, backgroundColor: colors.border, borderRadius: 2 },
  volumeFill: { width: '60%', height: 3, backgroundColor: colors.textSecondary, borderRadius: 2 },
  upNext: { marginTop: spacing.lg },
  upNextHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: spacing.sm },
  upNextTitle: { ...typography.h2, color: colors.textPrimary },
  seeAll: { ...typography.caption, color: colors.accent, fontWeight: '600' },
  upNextRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  upNextThumb: { width: 40, height: 40, borderRadius: radius.sm, backgroundColor: colors.surfaceElevated },
  upNextItemTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  upNextItemSubtitle: { ...typography.caption, color: colors.textSecondary },
});
