import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import SectionHeader from '../components/SectionHeader';
import MediaCard from '../components/MediaCard';
import MiniPlayer from '../components/MiniPlayer';
import { recentlyPlayed, continueListening } from '../data/mockData';

const MODULES = [
  { key: 'Music', label: 'Music', icon: 'musical-notes', color: colors.music },
  { key: 'Video', label: 'Video', icon: 'videocam', color: colors.video },
  { key: 'Podcasts', label: 'Podcasts', icon: 'mic', color: colors.podcast },
];

export default function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.logo}>Media<Text style={{ color: colors.accent }}>Hub</Text></Text>
        <Ionicons name="notifications-outline" size={22} color={colors.textPrimary} />
      </View>

      <TouchableOpacity style={styles.searchBar} onPress={() => navigation.navigate('Search')} activeOpacity={0.8}>
        <Ionicons name="search" size={16} color={colors.textSecondary} />
        <Text style={styles.searchPlaceholder}>Search music, videos, podcasts...</Text>
      </TouchableOpacity>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.moduleRow}>
          {MODULES.map((m) => (
            <TouchableOpacity
              key={m.key}
              style={styles.moduleItem}
              onPress={() => navigation.navigate(m.key)}
              activeOpacity={0.8}
            >
              <View style={[styles.moduleIcon, { backgroundColor: `${m.color}22`, borderColor: m.color }]}>
                <Ionicons name={m.icon} size={22} color={m.color} />
              </View>
              <Text style={styles.moduleLabel}>{m.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <SectionHeader title="Recently Played" onSeeAll={() => {}} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hList}>
          {recentlyPlayed.map((item) => (
            <MediaCard key={item.id} title={item.title} subtitle={item.subtitle} image={item.image} />
          ))}
        </ScrollView>

        <SectionHeader title="Continue Listening" onSeeAll={() => {}} />
        <View style={{ paddingHorizontal: spacing.md }}>
          {continueListening.map((item) => (
            <TouchableOpacity key={item.id} style={styles.continueRow} activeOpacity={0.7}>
              <View style={styles.continueThumb} />
              <View style={{ flex: 1, marginLeft: spacing.sm }}>
                <Text style={styles.continueTitle}>{item.title}</Text>
                <Text style={styles.continueMeta}>{item.meta}</Text>
              </View>
              <Ionicons name="play-circle" size={28} color={colors.accent} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: spacing.xl }} />
      </ScrollView>

      <MiniPlayer
        title="Midnight Drive"
        subtitle="The Night Owls"
        image={recentlyPlayed[0].image}
        target="NowPlayingAudio"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingTop: spacing.sm,
  },
  logo: { ...typography.h1, color: colors.textPrimary },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, borderRadius: radius.md,
    marginHorizontal: spacing.md, marginTop: spacing.md,
    paddingHorizontal: spacing.md, paddingVertical: 10,
  },
  searchPlaceholder: { ...typography.body, color: colors.textSecondary, marginLeft: spacing.sm },
  moduleRow: { flexDirection: 'row', paddingHorizontal: spacing.md, marginTop: spacing.lg },
  moduleItem: { alignItems: 'center', marginRight: spacing.lg },
  moduleIcon: {
    width: 56, height: 56, borderRadius: 28, borderWidth: 1.5,
    alignItems: 'center', justifyContent: 'center',
  },
  moduleLabel: { ...typography.caption, color: colors.textPrimary, marginTop: spacing.xs },
  hList: { paddingHorizontal: spacing.md },
  continueRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, borderRadius: radius.md,
    padding: spacing.sm, marginBottom: spacing.sm,
  },
  continueThumb: { width: 44, height: 44, borderRadius: radius.sm, backgroundColor: colors.surfaceElevated },
  continueTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  continueMeta: { ...typography.caption, color: colors.textSecondary },
});
