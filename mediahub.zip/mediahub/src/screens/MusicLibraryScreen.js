import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import MiniPlayer from '../components/MiniPlayer';
import { songs } from '../data/mockData';

const FILTERS = ['Songs', 'Albums', 'Artists', 'Genres'];

export default function MusicLibraryScreen({ navigation }) {
  const [active, setActive] = useState('Songs');

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Music</Text>
      </View>

      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity key={f} onPress={() => setActive(f)} style={[styles.filterChip, active === f && styles.filterChipActive]}>
            <Text style={[styles.filterText, active === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.shuffleRow}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Ionicons name="shuffle" size={16} color={colors.textPrimary} />
          <View style={{ marginLeft: spacing.sm }}>
            <Text style={styles.shuffleTitle}>Shuffle All</Text>
            <Text style={styles.shuffleMeta}>356 tracks</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.playCircle}>
          <Ionicons name="play" size={16} color={colors.background} />
        </TouchableOpacity>
      </View>

      <View style={styles.sortRow}>
        <Text style={styles.sortText}>Sort by: Recently Added</Text>
        <Ionicons name="chevron-down" size={14} color={colors.textSecondary} />
        <Ionicons name="filter" size={16} color={colors.textSecondary} style={{ marginLeft: 'auto' }} />
      </View>

      <ScrollView contentContainerStyle={styles.grid} showsVerticalScrollIndicator={false}>
        {songs.map((s) => (
          <TouchableOpacity
            key={s.id}
            style={styles.item}
            activeOpacity={0.7}
            onPress={() => navigation.navigate('NowPlayingAudio')}
          >
            <Image source={{ uri: s.image }} style={styles.thumb} />
            <Text style={styles.itemTitle} numberOfLines={1}>{s.title}</Text>
            <Text style={styles.itemSubtitle} numberOfLines={1}>{s.artist}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <MiniPlayer title="Midnight Drive" subtitle="The Night Owls" image={songs[0].image} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  title: { ...typography.h1, color: colors.textPrimary },
  filterRow: { flexDirection: 'row', paddingHorizontal: spacing.md, marginTop: spacing.md, gap: spacing.sm },
  filterChip: { paddingVertical: 6, paddingHorizontal: spacing.md, borderRadius: radius.pill, backgroundColor: colors.surface },
  filterChipActive: { backgroundColor: colors.accent },
  filterText: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  shuffleRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginHorizontal: spacing.md, marginTop: spacing.md,
    backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.sm,
  },
  shuffleTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  shuffleMeta: { ...typography.caption, color: colors.textSecondary },
  playCircle: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center' },
  sortRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.md, marginTop: spacing.md, gap: 4 },
  sortText: { ...typography.caption, color: colors.textSecondary },
  grid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: spacing.md, paddingTop: spacing.md, gap: spacing.md,
  },
  item: { width: '46%' },
  thumb: { width: '100%', aspectRatio: 1, borderRadius: radius.md, backgroundColor: colors.surfaceElevated },
  itemTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600', marginTop: spacing.xs },
  itemSubtitle: { ...typography.caption, color: colors.textSecondary },
});
