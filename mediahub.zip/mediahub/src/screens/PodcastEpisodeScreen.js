import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import { podcastChapters } from '../data/mockData';

export default function PodcastEpisodeScreen({ navigation }) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [position, setPosition] = useState(754); // 12:34
  const duration = 1456; // 24:16

  const format = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  return (
    <SafeAreaView style={styles.screen} edges={['top', 'bottom']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-down" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Ionicons name="ellipsis-horizontal" size={20} color={colors.textPrimary} />
      </View>

      <View style={styles.artworkCard}>
        <Text style={styles.showName}>TECH{'\n'}TALK{'\n'}DAILY</Text>
        <View style={styles.micBadge}>
          <Ionicons name="mic" size={14} color="#fff" />
        </View>
      </View>

      <Text style={styles.episodeTitle}>AI in 2024: What&apos;s Next?</Text>
      <Text style={styles.showLabel}>Tech Talk Daily</Text>

      <Slider
        style={{ width: '100%', height: 30, marginTop: spacing.md }}
        minimumValue={0}
        maximumValue={duration}
        value={position}
        onValueChange={setPosition}
        minimumTrackTintColor={colors.accent}
        maximumTrackTintColor={colors.border}
        thumbTintColor={colors.accent}
      />
      <View style={styles.timeRow}>
        <Text style={styles.timeText}>{format(position)}</Text>
        <Text style={styles.timeText}>{format(duration)}</Text>
      </View>

      <View style={styles.controlsRow}>
        <View style={styles.speedBadge}>
          <Text style={styles.speedText}>1.0x</Text>
          <Text style={styles.panelLabel}>Speed</Text>
        </View>
        <Ionicons name="play-back" size={22} color={colors.textPrimary} />
        <TouchableOpacity style={styles.playBtn} onPress={() => setIsPlaying(!isPlaying)}>
          <Ionicons name={isPlaying ? 'pause' : 'play'} size={28} color={colors.background} />
        </TouchableOpacity>
        <Ionicons name="play-forward" size={22} color={colors.textPrimary} />
        <View style={styles.timerBadge}>
          <Ionicons name="moon-outline" size={18} color={colors.textSecondary} />
          <Text style={styles.panelLabel}>Timer</Text>
        </View>
      </View>

      <View style={styles.actionsRow}>
        <TouchableOpacity style={styles.actionItem}>
          <Ionicons name="download-outline" size={18} color={colors.textSecondary} />
          <Text style={styles.actionLabel}>Download</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionItem}>
          <Ionicons name="share-social-outline" size={18} color={colors.textSecondary} />
          <Text style={styles.actionLabel}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionItem}>
          <Ionicons name="document-text-outline" size={18} color={colors.textSecondary} />
          <Text style={styles.actionLabel}>Show Notes</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.chaptersSection}>
        <Text style={styles.chaptersTitle}>Chapters</Text>
        {podcastChapters.map((c) => (
          <TouchableOpacity key={c.id} style={styles.chapterRow}>
            <Text style={styles.chapterTitle}>{c.title}</Text>
            <Text style={styles.timeText}>{c.time}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.md },
  header: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.sm },
  artworkCard: {
    alignSelf: 'center', width: '70%', aspectRatio: 1, borderRadius: radius.lg,
    backgroundColor: colors.surfaceElevated, borderWidth: 1, borderColor: colors.podcast,
    alignItems: 'center', justifyContent: 'center', marginTop: spacing.md,
  },
  showName: { ...typography.h1, color: colors.podcast, textAlign: 'center', lineHeight: 30 },
  micBadge: {
    position: 'absolute', bottom: 12, right: 12,
    width: 26, height: 26, borderRadius: 13, backgroundColor: colors.podcast,
    alignItems: 'center', justifyContent: 'center',
  },
  episodeTitle: { ...typography.h1, color: colors.textPrimary, marginTop: spacing.lg, textAlign: 'center' },
  showLabel: { ...typography.body, color: colors.textSecondary, textAlign: 'center', marginTop: 2 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between' },
  timeText: { ...typography.caption, color: colors.textSecondary },
  controlsRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: spacing.lg, paddingHorizontal: spacing.xs },
  speedBadge: { alignItems: 'center' },
  speedText: { ...typography.body, color: colors.textPrimary, fontWeight: '700' },
  panelLabel: { ...typography.caption, color: colors.textSecondary },
  playBtn: { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.textPrimary, alignItems: 'center', justifyContent: 'center' },
  timerBadge: { alignItems: 'center' },
  actionsRow: {
    flexDirection: 'row', justifyContent: 'space-around', marginTop: spacing.lg,
    paddingVertical: spacing.sm, borderTopWidth: 1, borderBottomWidth: 1, borderColor: colors.border,
  },
  actionItem: { alignItems: 'center', gap: 4 },
  actionLabel: { ...typography.caption, color: colors.textSecondary },
  chaptersSection: { marginTop: spacing.lg },
  chaptersTitle: { ...typography.h2, color: colors.textPrimary, marginBottom: spacing.sm },
  chapterRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  chapterTitle: { ...typography.body, color: colors.textPrimary },
});
