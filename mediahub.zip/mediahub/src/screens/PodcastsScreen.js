import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import SectionHeader from '../components/SectionHeader';
import MiniPlayer from '../components/MiniPlayer';
import { podcasts } from '../data/mockData';

export default function PodcastsScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Podcasts</Text>
        <TouchableOpacity style={styles.addBtn}>
          <Ionicons name="add" size={14} color="#fff" />
          <Text style={styles.addBtnText}>Add RSS Feed</Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <SectionHeader title="Subscribed" onSeeAll={() => {}} />
        <View style={{ paddingHorizontal: spacing.md }}>
          {podcasts.subscribed.map((p) => (
            <TouchableOpacity key={p.id} style={styles.row} activeOpacity={0.7}>
              <Image source={{ uri: p.image }} style={styles.showThumb} />
              <View style={{ flex: 1, marginLeft: spacing.sm }}>
                <Text style={styles.rowTitle}>{p.title}</Text>
                <Text style={styles.rowMeta}>{p.meta}</Text>
              </View>
              <Ionicons name="ellipsis-vertical" size={16} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>

        <SectionHeader title="Latest Episodes" />
        <View style={{ paddingHorizontal: spacing.md }}>
          {podcasts.latestEpisodes.map((e) => (
            <TouchableOpacity
              key={e.id}
              style={styles.row}
              activeOpacity={0.7}
              onPress={() => navigation.navigate('PodcastEpisode')}
            >
              <Image source={{ uri: e.image }} style={styles.showThumb} />
              <View style={{ flex: 1, marginLeft: spacing.sm }}>
                <Text style={styles.rowTitle} numberOfLines={1}>{e.title}</Text>
                <Text style={styles.rowMeta}>{e.meta}</Text>
              </View>
              <Ionicons name="download-outline" size={18} color={colors.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>
        <View style={{ height: spacing.xl }} />
      </ScrollView>

      <MiniPlayer title="Midnight Drive" subtitle="The Night Owls" image={podcasts.subscribed[0].image} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingTop: spacing.sm,
  },
  title: { ...typography.h1, color: colors.textPrimary },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.accent, borderRadius: radius.pill,
    paddingHorizontal: spacing.sm, paddingVertical: 6,
  },
  addBtnText: { ...typography.caption, color: '#fff', fontWeight: '600' },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  showThumb: { width: 48, height: 48, borderRadius: radius.sm, backgroundColor: colors.surfaceElevated },
  rowTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  rowMeta: { ...typography.caption, color: colors.textSecondary },
});
