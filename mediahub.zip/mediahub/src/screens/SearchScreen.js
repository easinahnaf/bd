import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import { searchResults } from '../data/mockData';

const TABS = ['All', 'Music', 'Video', 'Podcasts'];

export default function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('interstellar');
  const [activeTab, setActiveTab] = useState('All');

  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.searchBar}>
        <Ionicons name="search" size={16} color={colors.textSecondary} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          style={styles.input}
          placeholder="Search everything..."
          placeholderTextColor={colors.textSecondary}
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => setQuery('')}>
            <Ionicons name="close-circle" size={16} color={colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.tabRow}>
        {TABS.map((t) => (
          <TouchableOpacity key={t} onPress={() => setActiveTab(t)} style={[styles.tabChip, activeTab === t && styles.tabChipActive]}>
            <Text style={[styles.tabText, activeTab === t && styles.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {query.length > 0 ? (
          <>
            <Text style={styles.sectionTitle}>Top Result</Text>
            <TouchableOpacity style={styles.topResult} activeOpacity={0.7} onPress={() => navigation.navigate('NowPlayingVideo')}>
              <Image source={{ uri: searchResults.top.image }} style={styles.topResultThumb} />
              <View style={{ marginLeft: spacing.sm }}>
                <Text style={styles.rowTitle}>{searchResults.top.title}</Text>
                <Text style={styles.rowMeta}>{searchResults.top.meta}</Text>
              </View>
            </TouchableOpacity>

            <ResultSection title="Videos" items={searchResults.videos} onPress={() => navigation.navigate('NowPlayingVideo')} />
            <ResultSection title="Music" items={searchResults.music} onPress={() => navigation.navigate('NowPlayingAudio')} />
            <ResultSection title="Podcasts" items={searchResults.podcasts} onPress={() => navigation.navigate('PodcastEpisode')} />
          </>
        ) : (
          <View style={styles.recentHeader}>
            <Text style={styles.sectionTitle}>Recent Searches</Text>
            <Text style={styles.clearText}>Clear</Text>
          </View>
        )}

        {searchResults.recent.map((r) => (
          <TouchableOpacity key={r} style={styles.recentRow} onPress={() => setQuery(r)}>
            <Ionicons name="time-outline" size={16} color={colors.textSecondary} />
            <Text style={styles.recentText}>{r}</Text>
          </TouchableOpacity>
        ))}
        <View style={{ height: spacing.xl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function ResultSection({ title, items, onPress }) {
  return (
    <View>
      <View style={styles.recentHeader}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Text style={styles.clearText}>See All</Text>
      </View>
      {items.map((item) => (
        <TouchableOpacity key={item.id} style={styles.topResult} activeOpacity={0.7} onPress={onPress}>
          <Image source={{ uri: item.image }} style={styles.topResultThumb} />
          <View style={{ marginLeft: spacing.sm }}>
            <Text style={styles.rowTitle}>{item.title}</Text>
            <Text style={styles.rowMeta}>{item.meta}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: colors.surface, borderRadius: radius.md,
    marginHorizontal: spacing.md, marginTop: spacing.sm,
    paddingHorizontal: spacing.md, gap: spacing.sm,
  },
  input: { flex: 1, ...typography.body, color: colors.textPrimary, paddingVertical: 10 },
  tabRow: { flexDirection: 'row', paddingHorizontal: spacing.md, marginTop: spacing.md, gap: spacing.sm },
  tabChip: { paddingVertical: 6, paddingHorizontal: spacing.md, borderRadius: radius.pill, backgroundColor: colors.surface },
  tabChipActive: { backgroundColor: colors.accent },
  tabText: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
  tabTextActive: { color: '#fff' },
  sectionTitle: { ...typography.h2, color: colors.textPrimary, paddingHorizontal: spacing.md, marginTop: spacing.lg },
  recentHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, marginTop: spacing.lg,
  },
  clearText: { ...typography.caption, color: colors.accent, fontWeight: '600', marginTop: spacing.lg, marginRight: spacing.md },
  topResult: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: spacing.md, marginTop: spacing.sm,
  },
  topResultThumb: { width: 48, height: 48, borderRadius: radius.sm, backgroundColor: colors.surfaceElevated },
  rowTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600' },
  rowMeta: { ...typography.caption, color: colors.textSecondary },
  recentRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.md, paddingVertical: 10 },
  recentText: { ...typography.body, color: colors.textPrimary },
});
