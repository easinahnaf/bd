import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing, radius, typography } from '../theme/colors';
import SectionHeader from '../components/SectionHeader';
import MiniPlayer from '../components/MiniPlayer';
import { videos } from '../data/mockData';

export default function VideoLibraryScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.screen} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Video</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.addBtn}>
            <Ionicons name="add" size={14} color="#fff" />
            <Text style={styles.addBtnText}>Add Stream URL</Text>
          </TouchableOpacity>
          <Ionicons name="options-outline" size={20} color={colors.textPrimary} />
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <SectionHeader title="Recently Watched" onSeeAll={() => {}} />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.hList}>
          {videos.recentlyWatched.map((v) => (
            <TouchableOpacity
              key={v.id}
              style={styles.wideCard}
              activeOpacity={0.8}
              onPress={() => navigation.navigate('NowPlayingVideo')}
            >
              <Image source={{ uri: v.image }} style={styles.wideThumb} />
              <View style={styles.durationBadge}>
                <Text style={styles.durationText}>{v.meta}</Text>
              </View>
              <Text style={styles.itemTitle} numberOfLines={1}>{v.title}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <SectionHeader title="All Videos" />
        <View style={styles.grid}>
          {videos.all.map((v) => (
            <TouchableOpacity
              key={v.id}
              style={styles.gridItem}
              activeOpacity={0.8}
              onPress={() => navigation.navigate('NowPlayingVideo')}
            >
              <Image source={{ uri: v.image }} style={styles.gridThumb} />
              <View style={styles.durationBadgeSmall}>
                <Text style={styles.durationText}>{v.meta}</Text>
              </View>
              <Text style={styles.itemTitle} numberOfLines={1}>{v.title}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <View style={{ height: spacing.xl }} />
      </ScrollView>

      <MiniPlayer title="Midnight Drive" subtitle="The Night Owls" image={videos.all[0].image} target="NowPlayingVideo" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingTop: spacing.sm,
  },
  title: { ...typography.h1, color: colors.textPrimary },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.accent, borderRadius: radius.pill,
    paddingHorizontal: spacing.sm, paddingVertical: 6,
  },
  addBtnText: { ...typography.caption, color: '#fff', fontWeight: '600' },
  hList: { paddingHorizontal: spacing.md },
  wideCard: { width: 200, marginRight: spacing.md },
  wideThumb: { width: '100%', height: 112, borderRadius: radius.md, backgroundColor: colors.surfaceElevated },
  durationBadge: {
    position: 'absolute', bottom: 28, right: 8,
    backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: radius.sm,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  durationBadgeSmall: {
    position: 'absolute', bottom: 28, right: 8,
    backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: radius.sm,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  durationText: { color: '#fff', fontSize: 11, fontWeight: '600' },
  itemTitle: { ...typography.body, color: colors.textPrimary, fontWeight: '600', marginTop: spacing.xs },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: spacing.md, gap: spacing.md },
  gridItem: { width: '46%' },
  gridThumb: { width: '100%', aspectRatio: 4 / 3, borderRadius: radius.md, backgroundColor: colors.surfaceElevated },
});
