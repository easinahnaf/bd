export const recentlyPlayed = [
  { id: '1', title: 'Midnight Drive', subtitle: 'The Night Owls', image: 'https://picsum.photos/seed/drive/300/300', type: 'music' },
  { id: '2', title: 'Ocean Waves', subtitle: 'Nature Sounds', image: 'https://picsum.photos/seed/ocean/300/300', type: 'music' },
  { id: '3', title: 'Tech Talk Daily', subtitle: 'Podcast', image: 'https://picsum.photos/seed/tech/300/300', type: 'podcast' },
];

export const continueListening = [
  { id: '1', title: 'The Daily Brief', meta: '24m left', progress: 0.6, image: 'https://picsum.photos/seed/brief/300/300', type: 'podcast' },
  { id: '2', title: 'Chill Vibes Mix', meta: '12m left', progress: 0.4, image: 'https://picsum.photos/seed/chill/300/300', type: 'music' },
  { id: '3', title: 'Interstellar', meta: '45m left', progress: 0.3, image: 'https://picsum.photos/seed/interstellar/300/300', type: 'video' },
];

export const songs = [
  { id: '1', title: 'Midnight Drive', artist: 'The Night Owls', image: 'https://picsum.photos/seed/s1/300/300', duration: '3:45' },
  { id: '2', title: 'Neon Dreams', artist: 'Luna Skies', image: 'https://picsum.photos/seed/s2/300/300', duration: '4:12' },
  { id: '3', title: 'Echoes', artist: 'The Wanderer', image: 'https://picsum.photos/seed/s3/300/300', duration: '3:28' },
  { id: '4', title: 'Chill Vibes', artist: 'Various Artists', image: 'https://picsum.photos/seed/s4/300/300', duration: '5:01' },
  { id: '5', title: 'Golden Hour', artist: 'Tom Misch', image: 'https://picsum.photos/seed/s5/300/300', duration: '3:50' },
  { id: '6', title: 'Afterglow', artist: 'Luna Skies', image: 'https://picsum.photos/seed/s6/300/300', duration: '4:05' },
];

export const videos = {
  recentlyWatched: [
    { id: '1', title: 'Interstellar', meta: '2:49:04', image: 'https://picsum.photos/seed/v1/400/300' },
    { id: '2', title: 'The Batman', meta: '2:56:11', image: 'https://picsum.photos/seed/v2/400/300' },
  ],
  all: [
    { id: '3', title: 'Top Gear S32', meta: '45:21', image: 'https://picsum.photos/seed/v3/400/300' },
    { id: '4', title: 'Planet Earth II', meta: '58:34', image: 'https://picsum.photos/seed/v4/400/300' },
    { id: '5', title: 'Inception', meta: '2:28:08', image: 'https://picsum.photos/seed/v5/400/300' },
    { id: '6', title: 'Our Road Trip', meta: '32:17', image: 'https://picsum.photos/seed/v6/400/300' },
    { id: '7', title: 'The Office (US)', meta: '21:42', image: 'https://picsum.photos/seed/v7/400/300' },
  ],
};

export const podcasts = {
  subscribed: [
    { id: '1', title: 'The Daily Brief', meta: 'News · 452 episodes', image: 'https://picsum.photos/seed/p1/200/200' },
    { id: '2', title: 'Tech Talk Daily', meta: 'Technology · 312 episodes', image: 'https://picsum.photos/seed/p2/200/200' },
    { id: '3', title: 'Hidden Brain', meta: 'Science · 189 episodes', image: 'https://picsum.photos/seed/p3/200/200' },
  ],
  latestEpisodes: [
    { id: '1', show: 'The Daily Brief', title: 'AI in 2024: What\u2019s Next?', meta: 'May 22, 2024 · 24m', image: 'https://picsum.photos/seed/p1/200/200' },
    { id: '2', show: 'Tech Talk Daily', title: 'AI in 2024: What\u2019s Next?', meta: 'May 21, 2024 · 42m', image: 'https://picsum.photos/seed/p2/200/200' },
    { id: '3', show: 'Hidden Brain', title: 'The Power of Habits', meta: 'May 20, 2024 · 53m', image: 'https://picsum.photos/seed/p3/200/200' },
  ],
};

export const podcastChapters = [
  { id: '1', title: 'Intro', time: '00:00' },
  { id: '2', title: 'The State of AI', time: '05:12' },
  { id: '3', title: 'Future Trends', time: '18:45' },
];

export const searchResults = {
  recent: ['interstellar', 'chill vibes', 'tech talk daily'],
  top: { id: '1', title: 'Interstellar', meta: 'Movie · 2014 · 2:49:04', image: 'https://picsum.photos/seed/v1/300/300' },
  videos: [{ id: '1', title: 'Interstellar', meta: 'Movie · 2014', image: 'https://picsum.photos/seed/v1/300/300' }],
  music: [{ id: '2', title: 'Interstellar', meta: 'Luna Skies · 4:21', image: 'https://picsum.photos/seed/s2/300/300' }],
  podcasts: [{ id: '3', title: 'Interstellar Movie Review', meta: 'The Film Fanatics · 28m', image: 'https://picsum.photos/seed/p1/300/300' }],
};
