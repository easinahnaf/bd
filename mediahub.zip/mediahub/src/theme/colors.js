// Single source of truth for the dark, red-accented MediaHub look.
// Change a value here and it updates everywhere in the app.
export const colors = {
  background: '#0A0E14',
  surface: '#12171F',
  surfaceElevated: '#1A2029',
  border: '#232A35',

  accent: '#E63946',
  accentMuted: 'rgba(230, 57, 70, 0.15)',

  textPrimary: '#F5F6F8',
  textSecondary: '#8A93A3',
  textTertiary: '#565F6D',

  music: '#E63946',
  video: '#3AA6FF',
  podcast: '#8B5CF6',

  success: '#22C55E',
  divider: '#1E2530',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  pill: 999,
};

export const typography = {
  h1: { fontSize: 24, fontWeight: '700' },
  h2: { fontSize: 18, fontWeight: '700' },
  body: { fontSize: 14, fontWeight: '400' },
  caption: { fontSize: 12, fontWeight: '400' },
};
